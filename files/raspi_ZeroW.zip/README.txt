Raspberry Pi Zero W Case with mount holes (M3 screws, universal mount) by ascii_ch on Thingiverse: https://www.thingiverse.com/thing:4157037

Summary:
This is a remixed version of https://www.thingiverse.com/thing:2488316.I simply added some screw holes into the design so it can be combined with all other parts from my universal mount collection: https://www.thingiverse.com/ascii_ch/collections/universal-mount